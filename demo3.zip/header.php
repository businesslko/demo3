<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from https://factro.themetrades.com/html/demo/index.html by HTTrack Website Copier/3.x [XR&CO], Sat, 19 Sep 2026 17:20:54 GMT -->
<head>

	<!-- META ============================================= -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="canonical" href="index-2.html" />
	<!-- OG -->
	<meta name="robots" content="index, follow">
	
	<meta name="keywords" content="Web Design, Agency, Startup, Corporate, Creative, Studio, Marketing, Portfolio, Seo, Blogging, Development, Design" />
	<meta name="author" content="ThemeTrades" />
	<meta name="description" content="Factro is a Fully Creative Mobile Responsive HTML Template. It is designed specifically for Agency, Startup, Corporate, Creative, Studio, Marketing, Portfolio, Seo, Blogging, Development, Design or other Agencys." />
	
	<meta property="og:url" content="index-2.html" />
	<meta property="og:site_name" content="Factro : Construction Multipurpose HTML Template"/>
	<meta property="og:type" content="website" />
	<meta property="og:locale" content="en_us" />
	<meta property="og:title" content="Factro : Construction Multipurpose HTML Template" />
	<meta property="og:description" content="Factro is a Fully Creative Mobile Responsive HTML Template. It is designed specifically for Agency, Startup, Corporate, Creative, Studio, Marketing, Portfolio, Seo, Blogging, Development, Design or other Agencys" />
	<meta property="og:image" content="preview.png"/>
	
	<meta name="twitter:card" content="summary">
	<meta name="twitter:url" content="index-2.html">
	<meta name="twitter:creator" content="@themetrades">
	<meta name="twitter:title" content="Factro : Construction Multipurpose HTML Template">
	<meta name="twitter:description" content="Factro is a Fully Creative Mobile Responsive HTML Template. It is designed specifically for Agency, Startup, Corporate, Creative, Studio, Marketing, Portfolio, Seo, Blogging, Development, Design or other Agencys.">
	
	<meta name="format-detection" content="telephone=no">
	
	<!-- FAVICONS ICON ============================================= -->
	<link rel="icon" href="assets/images/favicon.ico" type="image/x-icon" />
	<link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png" />
	
	<!-- PAGE TITLE HERE ============================================= -->
	<title>Factro : Construction Multipurpose HTML Template </title>
	
	<!-- MOBILE SPECIFIC ============================================= -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<!--[if lt IE 9]>
	<script src="assets/js/html5shiv.min.js"></script>
	<script src="assets/js/respond.min.js"></script>
	<![endif]-->
	
	<!-- All PLUGINS CSS ============================================= -->
	<link rel="stylesheet" type="text/css" href="assets/css/assets.css">
	
	<!-- TYPOGRAPHY ============================================= -->
	<link rel="stylesheet" type="text/css" href="assets/css/typography.css">
	
	<!-- SHORTCODES ============================================= -->
	<link rel="stylesheet" type="text/css" href="assets/css/shortcodes/shortcodes.css">
	
	<!-- STYLESHEETS ============================================= -->
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link class="skin" rel="stylesheet" type="text/css" href="assets/css/color/color-2.css">
	<link class="skin" rel="stylesheet" type="text/css" href="assets/vendors/scroll/scrollbar.css">
	<link class="skin" rel="stylesheet" type="text/css" href="assets/vendors/swiper/swiper.min.css">
	
	<!-- REVOLUTION SLIDER CSS ============================================= -->
	<link rel="stylesheet" type="text/css" href="assets/vendors/revolution/css/layers.css">
	<link rel="stylesheet" type="text/css" href="assets/vendors/revolution/css/settings.css">
	<link rel="stylesheet" type="text/css" href="assets/vendors/revolution/css/navigation.css">
	<!-- REVOLUTION SLIDER END -->	
</head>
<body id="bg">
<div class="page-wraper">
<div id="loading-icon-bx"></div>
	<!-- Header Top ==== -->
    <header class="header rs-nav">
		<div class="top-bar">
			<div class="container">
				<div class="row d-flex justify-content-between">
					<div class="topbar-left">
						<ul>
							<li><a href="javascript:;"><i class="la la-phone"></i>Call Us (+00) 286 8591</a></li>
							<li><a href="javascript:;"><i class="la la-clock"></i>Mon to Fri - 9:00am - 6:00pm</a></li>
							<li><a href="javascript:;"><i class="las la-envelope-open"></i>Support@website.com</a></li>
						</ul>
					</div>
					<div class="topbar-right">
						<ul>
							<li><a href="company-history.html">History</a></li>
							<li><a href="blog-standard.html">News</a></li>
							<li><a href="contact-1.html">Contact Us</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="sticky-header navbar-expand-lg">
            <div class="menu-bar clearfix">
                <div class="container clearfix">
					<!-- Header Logo ==== -->
					<div class="menu-logo">
						<a href="index.html"><img src="assets/images/logo-2.png" alt=""></a>
					</div>
					<!-- Mobile Nav Button ==== -->
                    <button class="navbar-toggler collapsed menuicon justify-content-end" type="button" data-toggle="collapse" data-target="#menuDropdown" aria-controls="menuDropdown" aria-expanded="false" aria-label="Toggle navigation">
						<span></span>
						<span></span>
						<span></span>
					</button>
					<!-- Author Nav ==== -->
                    <div class="secondary-menu">
                        <div class="secondary-inner">
                            <ul>
								<li class="search-btn">
									<button id="quik-search-btn" type="button" class="btn-link"><i class="ti-search"></i></button>
								</li>
								<li>
									<a href="javascript:;" class="cart-btn">
										<span>0</span>
									</a>
									<ul class="dropdown-menu cart-list">
										<li class="cart-item">
											<div class="media"> 
												<div class="media-left"> 
													<a href="#"> 
														<img alt="" class="media-object" src="assets/images/product/pic1.jpg"> 
													</a> 
												</div> 
												<div class="media-body"> 
													<h6 class="title"><a href="#" class="media-heading">There are many variations of passages</a></h6>
													<span class="price">$25.00</span>
													<span class="item-close">&times;</span>
												</div> 
											</div>
										</li>
										<li class="cart-item">
											<div class="media"> 
												<div class="media-left"> 
													<a href="#"> 
														<img alt="" class="media-object" src="assets/images/product/pic2.jpg"> 
													</a> 
												</div> 
												<div class="media-body"> 
													<h6 class="title"><a href="#" class="media-heading">There are many variations of passages</a></h6>
													<span class="price">$22.00</span>
													<span class="item-close">&times;</span>
												</div> 
											</div>
										</li>
										<li class="cart-item subtotal">
											<h6 class="title m-a0">Subtotal <span>$47.00</span></h6>
										</li>
										<li class="d-flex">
											<button class="btn button-md flex-fill m-r5">View Cart</button>
											<button class="btn-secondry button-md flex-fill m-l5">Checkout</button>
										</li>
									</ul>
								</li>
								<li class="d-none d-sm-block">
									<a href="get-in-touch.html" class="btn">Get In Touch</a>
								</li>
							</ul>
						</div>
                    </div>
					<!-- Search Box ==== -->
                    <div class="nav-search-bar">
                        <form action="#">
                            <input name="search" value="" type="text" class="form-control" placeholder="Type to search">
                            <span><i class="ti-search"></i></span>
                        </form>
						<span id="search-remove"><i class="ti-close"></i></span>
                    </div>
					<!-- Navigation Menu ==== -->
                    <div class="menu-links navbar-collapse collapse justify-content-end" id="menuDropdown">
						<div class="menu-logo">
							<a href="index.html"><img src="assets/images/logo-2.png" alt=""></a>
						</div>
                        <ul class="nav navbar-nav">	
							<li class="active"><a href="javascript:;">Home<i class="fa fa-chevron-down"></i></a>
								<ul class="sub-menu">
									<li><a href="index.html"><span>Home - Default</span> </a></li>
									<li><a href="index-3.html"><span>Home - Energy & Power</span></a></li>
									<li><a href="index-4.html"><span>Home - Construction</span></a></li>
									<li><a href="index-5.html"><span>Home - Agricultural</span></a></li>
								</ul>
							</li>
							<li class="has-mega-menu "><a href="javascript:;">Pages<i class="fa fa-chevron-down"></i></a>
								<ul class="mega-menu">
									<li><a href="javascript:;">Pages</a>
										<ul>
											<li><a href="about-1.html"><span>About Us Simple</span></a></li>
											<li><a href="about-2.html"><span>About Us Classic</span></a></li>
											<li><a href="about-3.html"><span>About Us Modern</span></a></li>
											<li><a href="awards.html"><span>Awards</span></a></li>
											<li><a href="job-career.html"><span>Job & Career</span></a></li>
											<li><a href="partners.html"><span>Partners</span></a></li>
										</ul>
									</li>
									<li><a href="javascript:;">Pages</a>
										<ul>
											<li><a href="pricing.html"><span>Pricing</span></a></li>
											<li><a href="appointment.html"><span>Appointment</span></a></li>
											<li><a href="services-1.html"><span>Services Simple</span></a></li>
											<li><a href="services-2.html"><span>Services Classic</span></a></li>
											<li><a href="services-3.html"><span>Services Modern</span></a></li>
											<li><a href="services-details.html"><span>Services Details</span></a></li>
										</ul>
									</li>
									<li><a href="javascript:;">Pages</a>
										<ul>
											<li><a href="case-study.html"><span>Case study</span></a></li>
											<li><a href="case-details.html"><span>Case Details</span></a></li>
											<li><a href="company-history.html"><span>Company History</span></a></li>
											<li><a href="team.html"><span>Team</span></a></li>
											<li><a href="error-404.html"><span>404 Page</span></a></li>
											<li><a href="client.html"><span>Clients</span></a></li>
										</ul>
									</li>
									<li><a href="javascript:;">Pages</a>
										<ul>
											<li><a href="coming-soon.html"><span>Coming Soon</span></a></li>
											<li><a href="faq-1.html"><span>FAQ's 1</span></a></li>
											<li><a href="faq-2.html"><span>FAQ's 2</span></a></li>
											<li><a href="contact-1.html"><span>Contact Us 1</span></a></li>
											<li><a href="contact-2.html"><span>Contact Us 2</span></a></li>
											<li><a href="get-in-touch.html"><span>Get In Touch</span></a></li>
										</ul>
									</li>
								</ul>
							</li>
							<li><a href="javascript:;">Solution<i class="fa fa-chevron-down"></i></a>
								<ul class="sub-menu">
									<li class="add-menu-left">
										<ul>
											<li><a href="solution-agricultural-engineering.html"><span>Agricultural Engineering</span> </a></li>
											<li><a href="solution-chemical-research-engineering.html"><span>Chemical Research Engineering</span></a></li>
											<li><a href="solution-material-science-and-engineering.html"><span>Material Science and Engineering</span></a></li>
											<li><a href="solution-mechanical-engineering.html"><span>Mechanical Engineering</span></a></li>
											<li><a href="solution-oil-and-gas.html"><span>Oil and Gas</span></a></li>
											<li><a href="solution-power-and-energy.html"><span>Power and Energy</span></a></li>
										</ul>
									</li>
								</ul>
							</li>
							<li class="has-mega-menu "><a href="javascript:;">Projects <i class="fa fa-chevron-down"></i></a>
								<ul class="mega-menu">
									<li><a href="javascript:;">Projects Grid</a>
										<ul>
											<li><a href="projects-grid-2.html"><span>Projects Grid 2</span></a></li>
											<li><a href="projects-grid-3.html"><span>Projects Grid 3</span></a></li>
											<li><a href="projects-grid-4.html"><span>Projects Grid 4</span></a></li>
											<li><a href="projects-grid-wide.html"><span>Projects Grid Wide</span></a></li>
										</ul>
									</li>
									<li><a href="javascript:;">Projects Masonry</a>
										<ul>
											<li><a href="projects-masonry-grid-2.html"><span>Masonry Grid 2</span></a></li>
											<li><a href="projects-masonry-grid-3.html"><span>Masonry Grid 3</span></a></li>
											<li><a href="projects-masonry-grid-4.html"><span>Masonry Grid 4</span></a></li>
											<li><a href="projects-masonry-grid-wide.html"><span>Masonry Grid Wide</span></a></li>
										</ul>
									</li>
									<li><a href="javascript:;">Projects Style</a>
										<ul>
											<li><a href="projects-carousel-1.html"><span>Projects Carousel 1</span></a></li>
											<li><a href="projects-carousel-2.html"><span>Projects Carousel 2</span></a></li>
											<li><a href="projects-carousel-3.html"><span>Projects Carousel 3</span></a></li>
											<li><a href="projects-carousel-4.html"><span>Projects Carousel 4</span></a></li>
										</ul>
									</li>
									<li><a href="javascript:;">Projects Single</a>
										<ul>
											<li><a href="projects-single-1.html"><span>Projects Single 1</span></a></li>
											<li><a href="projects-single-2.html"><span>Projects Single 2</span></a></li>
											<li><a href="projects-single-3.html"><span>Projects Single 3</span></a></li>
											<li><a href="projects-single-4.html"><span>Projects Single 4</span></a></li>
										</ul>
									</li>
								</ul>
							</li>
							<li><a href="javascript:;">Shop<i class="fa fa-chevron-down"></i></a>
								<ul class="sub-menu">
									<li class="add-menu-left">
										<ul>
											<li><a href="shop.html"><span>Shop</span> </a></li>
											<li><a href="shop-sidebar.html"><span>Shop Sidebar</span></a></li>
											<li><a href="shop-cart.html"><span>Cart</span></a></li>
											<li><a href="shop-checkout.html"><span>Checkout</span></a></li>
											<li><a href="shop-details.html"><span>Product Details</span></a></li>
										</ul>
									</li>
								</ul>
							</li>
							<li><a href="javascript:;">Blog <i class="fa fa-chevron-down"></i></a>
								<ul class="sub-menu left">
									<li><a href="blog-standard.html"><span>Blog Standard</span></a></li>
									<li><a href="blog-classic.html"><span>Blog Classic</span></a></li>
									<li><a href="blog-classic-sidebar.html"><span>Blog Classic Sidebar</span></a></li>
									<li><a href="blog-list.html"><span>Blog List Sidebar</span></a></li>
									<li><a href="blog-masonry.html"><span>Masonry</span></a></li>
									<li><a href="blog-details-sidebar.html"><span>Blog Details</span></a></li>
								</ul>
							</li>
						</ul>
						<div class="nav-social-link">
							<a href="javascript:;"><i class="fa fa-facebook"></i></a>
							<a href="javascript:;"><i class="fa fa-google-plus"></i></a>
							<a href="javascript:;"><i class="fa fa-linkedin"></i></a>
						</div>
                    </div>
					<!-- Navigation Menu END ==== -->
                </div>
            </div>
        </div>
    </header>
    <!-- Header Top END ==== -->
